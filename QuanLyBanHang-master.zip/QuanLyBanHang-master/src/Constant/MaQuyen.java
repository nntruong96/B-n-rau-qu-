package Constant;

public class MaQuyen {

    public static final String QUANLY = "0";
    public static final String QUANLY_TAIKHOAN = "1";
    public static final String QUANLY_VAITRO = "2";
    public static final String QUANLY_NHANVIEN = "3";
    public static final String QUANLY_NHACUNGCAP = "4";
    public static final String QUANLY_SANPHAM = "5";
    public static final String QUANLY_NHAPXUAT_HOADONBANHANG = "6";
    public static final String QUANLY_NHAPXUAT_HOADONNHAPHANG = "7";
    public static final String QUANLY_DATHANG = "8";
    public static final String QUANLY_HOADON = "9";

}
